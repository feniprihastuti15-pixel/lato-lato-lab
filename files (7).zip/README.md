# 🪀 Virtual Lab Lato-Lato: Gerak Harmonik & Tumbukan

Simulasi interaktif berbasis **p5.js** yang memodelkan lato-lato sebagai dua bandul pada satu poros yang saling bertumbukan. Dipakai sebagai laboratorium virtual untuk materi **gerak harmonik sederhana (GHS)** dan **tumbukan**.

🔗 **Demo:** https://USERNAME.github.io/NAMA-REPOSITORI/
📁 **Kode:** https://github.com/USERNAME/NAMA-REPOSITORI

> Ganti `USERNAME` dan `NAMA-REPOSITORI` dengan milik kelompok.

## Tujuan

- Mengamati hubungan panjang tali, massa, dan percepatan gravitasi terhadap gerak bandul.
- Menyelidiki kekekalan momentum dan pengaruh koefisien restitusi (e) pada tumbukan.
- Melihat mengapa lato-lato berhenti berbunyi bila tidak "dipompa" oleh tangan.

## Fitur

- Animasi dua bola (merah dan kuning) dengan tumbukan berdasarkan fisika, termasuk kilatan "klak".
- Slider per bola: panjang tali (L), massa (m), sudut awal (θ₀).
- Parameter umum: koefisien restitusi (e), redaman udara, dan pilihan gravitasi (Bulan, Mars, Bumi, Jupiter).
- Tombol **Mulai/Jeda**, **Reset**, dan **Beri Dorongan** (meniru tambahan energi dari tangan).
- Panel data real-time: sudut, kecepatan, waktu, jumlah tumbukan, energi mekanik, dan momentum total.
- Grafik simpangan sudut θ(t) dan grafik energi mekanik total.
- Log tumbukan (kecepatan dan momentum sebelum dan sesudah, serta perubahan energi kinetik).
- Dasar teori singkat dan kuis pemahaman.

## Cara menggunakan

1. Buka tautan demo di browser (komputer atau HP).
2. Atur parameter pada slider. Perubahan sudut awal (θ₀) baru berlaku setelah klik **Reset**.
3. Klik **Mulai**, lalu amati animasi, grafik, dan log tumbukan.
4. Untuk percobaan terkontrol, ubah **satu** variabel saja dan biarkan yang lain tetap.

### Contoh percobaan

| Percobaan | Yang diubah | Yang diamati |
|---|---|---|
| Jenis tumbukan | e = 1; 0,5; 0 | Energi kinetik hilang atau tidak, jumlah tumbukan sampai berhenti |
| Pengaruh massa | m₂ lebih kecil dan lebih besar dari m₁ | Kecepatan sesudah tumbukan, kekekalan momentum di log |
| Batas GHS | θ₀ = 10° lalu 60° | Bentuk grafik θ(t) dan periode ayunan |
| Pengaruh gravitasi | Bulan, Bumi, Jupiter | Periode ayunan (T = 2π√(L/g)) |

## Dasar fisika

- Persamaan gerak bandul: d²θ/dt² = −(g/L)·sin θ − c·dθ/dt (c = redaman udara).
- Tumbukan dihitung dengan impuls sepanjang garis hubung kedua pusat bola, memakai koefisien restitusi: e = −(v₂′ − v₁′)/(v₂ − v₁).
- Momentum selalu kekal saat tumbukan; energi kinetik kekal hanya bila e = 1.
- Integrasi numerik: semi-implicit Euler dengan langkah waktu kecil (1 ms) agar tumbukan tidak "tembus".

## Struktur berkas

```
├── index.html   # memuat p5.js dan sketch.js
├── sketch.js    # seluruh kode simulasi dan antarmuka
└── README.md    # dokumen ini
```

## Menjalankan di komputer sendiri

1. Unduh atau klon repositori ini.
2. Buka `index.html` dengan browser (perlu koneksi internet untuk memuat p5.js dari CDN).

## Keterbatasan model

- Idealisasi 2D: tali tegar dan tak bermassa, bola dianggap partikel dengan jari-jari tertentu.
- Tumbukan dianggap sangat singkat; gesekan udara hanya dimodelkan sebagai redaman linear sederhana.
- Tombol "Beri Dorongan" hanya pendekatan sederhana dari gerakan tangan pemain.

## Tim

| Nama | Peran |
|---|---|
| (Nama anggota 1) | (mis. model fisika) |
| (Nama anggota 2) | (mis. tampilan dan antarmuka) |
| (Nama anggota 3) | (mis. grafik dan analisis data) |
| (Nama anggota 4) | (mis. laporan dan dokumentasi) |

Mata kuliah: (nama mata kuliah) · Program Studi: (prodi) · Dosen pengampu: (nama dosen)

## Teknologi

- [p5.js](https://p5js.org/) (dimuat dari cdnjs)
- HTML, CSS, dan JavaScript
- GitHub Pages untuk publikasi
